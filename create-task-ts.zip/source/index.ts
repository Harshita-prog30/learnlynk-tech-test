// For JSR import
import { createClient } from "jsr:@supabase/supabase-js";

// OR for npm import
import { createClient } from "npm:@supabase/supabase-js";


// Supabase client with service role
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(supabaseUrl, supabaseKey);

serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Use POST only" }), { status: 405 });
  }

  try {
    const body = await req.json();
    const { application_id, task_type, due_at } = body;

    // Validation
    if (!["call", "email", "review"].includes(task_type)) {
      return new Response(JSON.stringify({ error: "task_type invalid" }), { status: 400 });
    }
    if (new Date(due_at) <= new Date()) {
      return new Response(JSON.stringify({ error: "due_at must be future date" }), { status: 400 });
    }

    // Insert task
    const { data, error } = await supabase
      .from("tasks")
      .insert([{ application_id, task_type, due_at }])
      .select()
      .single();

    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });

    // Return success
    return new Response(JSON.stringify({ success: true, task_id: data.id }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });

  } catch (err) {
    return new Response(JSON.stringify({ error: "Something went wrong" }), { status: 500 });
  }
});
